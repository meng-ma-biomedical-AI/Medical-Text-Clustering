import os
import re
import codecs
import jieba
import pickle
import pandas as pd
from tqdm import tqdm
from elasticsearch import Elasticsearch
from elasticsearch.client import IndicesClient

es = Elasticsearch([{'host':'localhost','port':9200}])

es_idx = IndicesClient(es)

es_idx.delete(index='_all')

a = os.popen('''
curl -X PUT 'localhost:9200/main_idx' -d '
{
  "mappings": {
    "docs": {
      "properties": {
        "pure_text": {
          "type": "text",
          "analyzer": "ik_max_word",
          "search_analyzer": "ik_max_word"
        },
        "processed_text": {
          "type": "text",
          "analyzer": "ik_max_word",
          "search_analyzer": "ik_max_word"
        }
      }
    }
  }
}'
''').read()

Herceptin_question = pd.read_excel('./data/Herceptin.xlsx')
Kadcyla_question = pd.read_excel('./data/Kadcyla.xlsx')
Perjeta_1_question = pd.read_excel('./data/Perjeta_1.xlsx')
Perjeta_2_question = pd.read_excel('./data/Perjeta_2.xlsx')
Tecentriq_question = pd.read_excel('./data/Tecentriq.xlsx')
Xeloda_question = pd.read_excel('./data/Xeloda.xlsx')
No_product_question = pd.read_excel('./data/No_product_merged.xlsx')

all_question = pd.concat([Herceptin_question, Kadcyla_question, Perjeta_1_question, Perjeta_2_question, Tecentriq_question, Xeloda_question, No_product_question])

all_question.dropna(axis=0, inplace=True, subset=['Description'])

jieba.load_userdict('./data/chinese_word_dict.txt')
chinese_word_dict = pickle.load(open('./data/chinese_word_dict.pickle', 'rb'))
stopwords = [line.strip() for line in codecs.open('./data/stopwords-zh.txt', 'r', encoding='utf8').readlines()]

def keyword_extract(text, word_dict):
#     text = list(jieba.cut(text, cut_all=False))
    text = list(jieba.cut_for_search(text))
    union_text = list(set(text).intersection(set(word_dict)))
    return " ".join(union_text)

all_question['KeyWords'] = all_question.Description.apply(lambda x: keyword_extract(x, chinese_word_dict))

# 去除所有“[]”内的文本
def remove_special_string(text):
    text = re.sub(r'\[[^]]*\]', '', text)
    text = re.sub(r'\([^)]*\)', '', text)
    text = re.sub(r'（[^）]*\）', '', text)
    text = re.sub(r'\<[^>]*\>', '', text)
#     text = re.sub(r'[0-9]*', '', text)
#     text = re.sub('患者', '', text)
#     text = re.sub('家属', '', text)
#     text = re.sub('咨询', '', text)
#     text = re.sub('询问', '', text)
    return text
def remove_stopwords(text, stopwords):
    text_cutted = jieba.cut(text, cut_all=True)
    text_removed = []
    for word in text_cutted:
        if word in stopwords or word.strip()=="":
            continue
        text_removed.append(word)
    return "  ".join(text_removed)

all_question['Description'] = all_question.Description.apply(lambda x: remove_special_string(x))
all_question['Processed'] = all_question.Description.apply(lambda x: remove_special_string(x))
all_question['Processed'] = all_question.Processed.apply(lambda x: remove_stopwords(x, stopwords))

doc_list = []
for idx,row in all_question.iterrows():
    doc = {"pure_text": row['Description'], "processed_text": row['KeyWords']}
    doc_list.append(doc)

for doc in tqdm(doc_list):
    temp = os.popen('''
    curl -X POST 'localhost:9200/main_idx/docs' -d '
    {}
    '
    '''.format(str(doc).replace("\"", "\'").replace("\'", "\""))).read()

print('Rebuild Index Done.')