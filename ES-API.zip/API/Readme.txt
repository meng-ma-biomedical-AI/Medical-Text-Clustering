
安装相应python包

打开ElasticSearch: 运行 /elasticsearch-5.6.15/bin/elasticsearch 文件 (保持运行状态 默认端口为9200)
ElasticSearch运行需要系统已安装Java环境!

运行create_index.py文件(建索引，只用建一次，原始数据不变就不用再次运行)

运行search.py，运行时传入参数query，例如：
python3 search.py "心脏毒性？"